# Deep-fake-detector

Deep-fake-detector



````markdown
# 🕵️‍♂️ Deepfake Detection Platform — 

> **MERN Stack | Hugging Face API | FFmpeg | Real-Time Socket.IO Notifications**

Base URL: [https://deepfake-51fk.onrender.com](https://deepfake-51fk.onrender.com)

---

## 🚀 Tech Stack

- **Frontend:** React (Vite)
- **Backend:** Node.js, Express
- **Database:** MongoDB
- **Real-Time:** Socket.IO
- **AI/ML:** Hugging Face Inference API
- **Video Processing:** FFmpeg

---

## 📁 1. Environment Variables

Create a `.env` file (locally) or configure variables in **Render Dashboard**.

```env
# Server
PORT=5000
MONGODB_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/dbname
JWT_SECRET=supersecretjwtkey

# Hugging Face
HF_API_KEY=hf_xxxYourHfApiKeyxxxx
HF_MODEL_AI=umm-maybe/AI-image-detector
HF_MODEL_DF=dima806/deepfake_vs_real_image_detection
```
````

### How to Set on Render:

1. Open your service → **Environment** tab.
2. Add the following:

   - `HF_API_KEY`
   - `HF_MODEL_AI`
   - `HF_MODEL_DF`

3. Save and **Redeploy**.

> ⚠️ **Keep `HF_API_KEY` secret!** Never expose it in the frontend.

---

## 🏗 2. System Architecture (High-Level)

```plaintext
Client (React/Vite) ─┬─> POST /api/detect/file (Upload File)
                     │
                     └─> Socket.IO for real-time analysis updates

Backend (Express) ──> Hugging Face API + FFmpeg
                     └─> MongoDB (Store results)
Admin Dashboard ────> /api/admin/*
```

### Components:

- **Frontend:** Upload UI, user dashboard, admin dashboard
- **Backend:** Auth, detection, history, admin APIs
- **Hugging Face:** Model inference via `HF_API_KEY`
- **FFmpeg:** Frame extraction for videos
- **MongoDB:** Store user and upload metadata
- **Socket.IO:** Notify users when detection is complete

---

## 🧱 3. Mongoose Models

### `models/User.js`

```js
{
  username: String,
  email: String,
  password: String, // hashed
  role: 'user' | 'admin',
  isSuspended: Boolean,
  lastLogin: Date,
  uploadsCount: Number
}
```

### `models/Upload.js`

```js
{
  filename: String,
  originalName: String,
  mimetype: String,
  size: Number,
  url: String,
  user: ObjectId (ref: 'User'),
  results: Mixed,
  verdict: String,
  confidence: Number
}
```

---

## 🔌 4. Backend API Reference

Base URL: `https://deepfake-51fk.onrender.com/api`

### Auth

#### `POST /auth/register`

```json
{ "username": "abc", "email": "abc@mail.com", "password": "123456" }
```

#### `POST /auth/login`

```json
{ "email": "abc@mail.com", "password": "123456" }
```

#### `GET /auth/me`

**Header:** `Authorization: Bearer <token>`

---

### Detection

#### `POST /detect/file`

**Protected Route**

- **Header:** `Authorization: Bearer <token>`
- **Body:** `multipart/form-data` with file
- **Behavior:**

  - If **image**: Run both Hugging Face models
  - If **video**: Extract frames via FFmpeg, analyze
  - Emit `analysis_complete` via Socket.IO
  - Save Upload to DB

**Example Response:**

```json
{
  "success": true,
  "results": {
    "AI Image Detector": [{ "label": "artificial", "score": 0.87 }],
    "Deepfake Detector": [{ "label": "Real", "score": 0.84 }]
  },
  "verdict": { "verdict": "Real", "confidence": 86 }
}
```

#### `GET /history`

- **Headers:** `Authorization: Bearer <token>`
- **Query:** `?page=1&limit=20`

---

### Admin (Requires `admin` Role)

#### `GET /admin/users`

Supports: `?search=...&role=...&status=...`

#### `PATCH /admin/user/:id`

Update:

```json
{ "role": "admin" } or { "suspend": true }
```

#### `DELETE /admin/user/:id`

#### `GET /admin/dashboard`

Returns system KPIs and analytics.

---

## 🧠 5. Hugging Face Model Calls

### Helper Function

```js
const res = await axios.post(
  `https://api-inference.huggingface.co/models/${modelId}`,
  imageBuffer,
  {
    headers: {
      Authorization: `Bearer ${process.env.HF_API_KEY}`,
      "Content-Type": "application/octet-stream",
    },
  }
);
```

### Model Config

```js
const models = {
  ai: process.env.HF_MODEL_AI || "umm-maybe/AI-image-detector",
  df: process.env.HF_MODEL_DF || "dima806/deepfake_vs_real_image_detection",
};
```

> ⚠️ Models may return labels like: `artificial`, `human`, `Real`, `Fake`. Always **normalize casing**.

---

## 🧮 6. Verdict Algorithm

### Example:

1. Extract scores:

   - `aiArtificial`: label matches `/artificial|fake|synthetic/`
   - `aiHuman`: `/human|real/`
   - `dfFake`: `/fake|manipulated/`
   - `dfReal`: `/real|authentic/`

2. Rules:

```js
if (aiArtificial > 0.8 && dfReal > 0.6) {
  verdict = "AI-Generated";
} else if (dfFake > 0.6) {
  verdict = "Deepfake/Manipulated";
} else if (aiHuman > 0.7 && dfReal > 0.7) {
  verdict = "Real";
} else {
  verdict = "Uncertain";
}
```

---

## 📡 7. Real-Time Notifications (Socket.IO)

### Server

- Maps `userId → socketId`
- On connect: Client emits `register_user`
- On detection complete:

```js
io.to(socketId).emit("analysis_complete", {
  id,
  filename,
  verdict,
  confidence,
  url,
  createdAt,
});
```

### Client Example

```js
const socket = io(BACKEND_URL, { auth: { token } });
socket.on("connect", () => socket.emit("register_user", user._id));
socket.on("analysis_complete", (data) => {
  // play sound, update UI
});
```

---

## 📦 8. Upload Limits

- **Images:** ≤ 5MB
- **Videos:** ≤ 50MB
- Use **chunked uploads** for large files if needed.

---

## 🎞 9. FFmpeg (Video Processing)

- FFmpeg path: `/usr/bin/ffmpeg`
- Installed via `apt.txt` on Render
- Extract frames → analyze → aggregate results

---

## 🔐 10. Security Practices

- Hash passwords with `bcrypt`
- Use `JWT` with expiry
- Sanitize filenames and validate types
- Use **HTTPS** (Render provides TLS)
- Role-based access for admin
- Consider rate-limiting (e.g., `express-rate-limit`)

---

## 💰 11. Cost & Optimization

- Hugging Face API can be **costly** — batch frames, limit FPS
- FFmpeg uses CPU/RAM — offload processing to **worker queues** if needed

---

## 📬 12. Sample Requests

### Upload Image

```bash
curl -X POST "https://deepfake-51fk.onrender.com/api/detect/file" \
  -H "Authorization: Bearer <TOKEN>" \
  -F "file=@/path/to/image.jpg"
```

### Admin Dashboard Stats

```bash
curl -H "Authorization: Bearer <ADMIN_TOKEN>" \
  "https://deepfake-51fk.onrender.com/api/admin/dashboard"
```

---

## 🧪 13. Model Notes

### `umm-maybe/AI-image-detector`

- Detects AI-generated vs real photos
- Output: `artificial`, `human`

### `dima806/deepfake_vs_real_image_detection`

- Face swap deepfake detection
- Output: `Real`, `Fake`

---

## ⚡️ 14. Developer Quickstart (Local)

```bash
# Backend
git clone <repo>
cd backend
cp .env.example .env  # Add your env vars
npm install
node server.js

# Frontend
cd ../frontend
npm install
npm run dev
```

> ✅ Ensure `ffmpeg` is installed (via `apt`, `brew`, or package manager)

---

##
