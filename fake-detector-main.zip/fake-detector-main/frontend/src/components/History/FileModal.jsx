import React from "react";

const FileModal = ({ file, onClose }) => {
  console.log({ file });

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="close-btn" onClick={onClose}>
          ×
        </button>

        <h3>{file.originalName || file.filename}</h3>

        {/* Media Preview */}
        {file.mimetype?.startsWith("image") && (
          <img
            src={import.meta.env.VITE_BACKEND_URL + file.url}
            alt={file.name}
            className="preview-media"
          />
        )}
        {file.mimetype?.startsWith("video") && (
          <video
            src={import.meta.env.VITE_BACKEND_URL+file.url}
            controls
            className="preview-media"
          />
        )}
        {file.mimetype?.startsWith("audio") && (
          <audio src={import.meta.env.VITE_BACKEND_URL+file.url} controls className="preview-media" />
        )}

        {file.explainability && (
          <div className="explainability">
            <h4>Explainability Overlay:</h4>
            <img src={file.explainability} alt="Explainability" />
          </div>
        )}

        {/* Summary Verdict */}
        <div className="verdict-summary">
          <p>
            Prediction: <b>{file.verdict}</b>
          </p>
          <p>
            Confidence: <b>{file.confidence}%</b>
          </p>
        </div>

        {/* Detailed Results */}
        <div className="detector-results">
          {file.results?.["AI Image Detector"] && (
            <div className="detector-section">
              <h4>AI Image Detector</h4>
              <ul>
                {file.results["AI Image Detector"].map((r, i) => (
                  <li key={i}>
                    <strong>{r.label}</strong>: {(r.score * 100).toFixed(2)}%
                  </li>
                ))}
              </ul>
            </div>
          )}

          {file.results?.["Deepfake Detector"] && (
            <div className="detector-section">
              <h4>Deepfake Detector</h4>
              <ul>
                {file.results["Deepfake Detector"].map((r, i) => (
                  <li key={i}>
                    <strong>{r.label}</strong>: {(r.score * 100).toFixed(2)}%
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FileModal;
