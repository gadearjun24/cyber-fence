import React from "react";

const FilterBar = ({ filters, setFilters, setLoading }) => {
  return (
    <div className="filter-bar">
      {/* <input
        type="text"
        placeholder="Search by filename"
        value={filters.filename || ""}
        onChange={(e) => setFilters({ ...filters, filename: e.target.value })}
      /> */}
      <select
        value={filters.type}
        onChange={(e) => {
          setLoading(true);
          setFilters({ ...filters, type: e.target.value });
        }}
      >
        <option value="">All Types</option>
        <option value="image">Image</option>
        <option value="video">Video</option>
        <option value="audio">Audio</option>
      </select>
      <select
        value={filters.prediction}
        onChange={(e) => setFilters({ ...filters, prediction: e.target.value })}
      >
        <option value="">All Results</option>
        <option value="Real">Real</option>
        <option value="Deepfake/Manipulated">Fake</option>
        <option value="AI-Generated">AI-Generated</option>
        <option value="Uncertain">Uncertain</option>
      </select>
      {/* <input
        type="date"
        value={filters.date}
        onChange={(e) => setFilters({ ...filters, date: e.target.value })}
      /> */}
    </div>
  );
};

export default FilterBar;
