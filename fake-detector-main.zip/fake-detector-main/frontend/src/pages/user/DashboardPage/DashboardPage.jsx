import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./DashboardPage.css";
import Header from "../../../components/Header/Header";
import { useAuth } from "../../../context/AuthContext";

const DashboardPage = () => {
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const { token } = useAuth();
  const navigate = useNavigate();

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    validateAndSetFile(selectedFile);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    validateAndSetFile(droppedFile);
  };

  const validateAndSetFile = (selectedFile) => {
    if (!selectedFile) return;

    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "video/mp4",
      "audio/wav",
      "audio/mpeg",
    ];

    if (!allowedTypes.includes(selectedFile.type)) {
      setError("Unsupported file type.");
      return;
    }

    const maxSize = selectedFile.type.startsWith("video/")
      ? 50 * 1024 * 1024
      : 5 * 1024 * 1024;

    if (selectedFile.size > maxSize) {
      setError("File exceeds maximum allowed size.");
      return;
    }

    setError("");
    setFile(selectedFile);
    setPreviewUrl(URL.createObjectURL(selectedFile));
    setResult(null);
    setUploadProgress(0);
  };

  const handleUpload = async () => {
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);

    try {
      if (!token) {
        navigate("/login");
        return;
      }
      const response = await axios.post(
        `${import.meta.env.VITE_BACKEND_URL}/api/detect/file`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
          onUploadProgress: (progressEvent) => {
            const percent = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            // if (percent === 100) {
            //   alert("After analysing we will notify you.");
            // }
            setUploadProgress(percent);
          },
        }
      );

      console.log({ response });
      setResult(response.data.results);
    } catch (err) {
      console.error(err);
      setError("Upload failed. Please try again.");
    }
  };

  return (
    <>
      <Header title="Dashboard" />
      <div className="dashboard-page">
        <h2 className="page-title">Upload File</h2>

        {/* Upload Area */}
        <div
          className="upload-zone"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
        >
          <p>Drag & drop a file here or click to select</p>
          <input
            type="file"
            onChange={handleFileChange}
            className="file-input"
          />
        </div>

        {file && (
          <div className="file-info">
            <p>
              <strong>File Name:</strong> {file.name}
            </p>
            <p>
              <strong>Type:</strong> {file.type}
            </p>
            <p>
              <strong>Size:</strong> {(file.size / 1024 / 1024).toFixed(2)} MB
            </p>

            <button className="upload-btn" onClick={handleUpload}>
              Upload File
            </button>

            {uploadProgress > 0 && (
              <div className="progress-bar">
                <div
                  className="progress"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
            )}
          </div>
        )}

        {error && <p className="error-text">{error}</p>}

        {/* Result Section */}
        {result && (
          <div className="result-card">
            {/* File Preview */}
            {previewUrl && (
              <>
                {file.type.startsWith("image") && (
                  <img width={300} src={previewUrl} alt="Uploaded" />
                )}
                {file.type.startsWith("video") && (
                  <video src={previewUrl} controls />
                )}
                {file.type.startsWith("audio") && (
                  <audio src={previewUrl} controls />
                )}
              </>
            )}

            {/* Results */}
            <div className="result-info">
              {/* AI Image Detector */}
              {result["AI Image Detector"] && (
                <div className="detector-section">
                  <h3>AI Image Detector</h3>
                  <ul>
                    {result["AI Image Detector"].map((r, i) => {
                      const badgeClass =
                        r.label.toLowerCase() === "artificial"
                          ? "fake-badge"
                          : r.label.toLowerCase() === "human"
                          ? "real-badge"
                          : "neutral-badge";

                      return (
                        <li key={i}>
                          <strong>{r.label}</strong>
                          <span className={badgeClass}>
                            {(r.score * 100).toFixed(2)}%
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}

              {/* Deepfake Detector */}
              {result["Deepfake Detector"] && (
                <div className="detector-section">
                  <h3>Deepfake Detector</h3>
                  <ul>
                    {result["Deepfake Detector"].map((r, i) => {
                      const badgeClass =
                        r.label.toLowerCase() === "real"
                          ? "real-badge"
                          : r.label.toLowerCase() === "fake"
                          ? "fake-badge"
                          : "neutral-badge";

                      return (
                        <li key={i}>
                          <strong>{r.label}</strong>
                          <span className={badgeClass}>
                            {(r.score * 100).toFixed(2)}%
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default DashboardPage;
