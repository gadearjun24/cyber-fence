// src/pages/admin/Dashboard.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Dashboard.css";
import { Upload } from "lucide-react"; // icon
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import Header from "../../../components/Header/Header";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../../context/AuthContext";

// Dummy colors for charts
const COLORS = ["#4f46e5", "#22c55e", "#ef4444", "#facc15"];

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    inactiveUsers: 0,
    totalUploads: 0,
    uploadsToday: 0,
    uploadsThisWeek: 0,
    flaggedAI: 0,
    flaggedDeepfake: 0,
    flaggedUncertain: 0,
    systemAlerts: 0,
  });

  const [uploadTrends, setUploadTrends] = useState([]);
  const [detectionRatios, setDetectionRatios] = useState([]);
  const [loading, setLoading] = useState(true);

  const { token } = useAuth();
  const navigate = useNavigate();

  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  // Handle file select
  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    validateAndSetFile(selectedFile);
  };

  // Handle drag & drop
  const handleDrop = (e) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    validateAndSetFile(droppedFile);
  };

  // Validate file
  const validateAndSetFile = (selectedFile) => {
    if (!selectedFile) return;

    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "video/mp4",
      "audio/wav",
      "audio/mpeg",
    ];

    if (!allowedTypes.includes(selectedFile.type)) {
      setError("❌ Unsupported file type.");
      return;
    }

    const maxSize = selectedFile.type.startsWith("video/")
      ? 50 * 1024 * 1024 // 50MB for video
      : 5 * 1024 * 1024; // 5MB for image/audio

    if (selectedFile.size > maxSize) {
      setError("❌ File exceeds maximum allowed size.");
      return;
    }

    setError("");
    setFile(selectedFile);
    setPreviewUrl(URL.createObjectURL(selectedFile));
    setResult(null);
    setUploadProgress(0);
  };

  // Upload to backend
  const handleUpload = async () => {
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      if (!token) {
        navigate("/login");
        return;
      }

      const response = await axios.post(
        `${import.meta.env.VITE_BACKEND_URL}/api/detect/file`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
          onUploadProgress: (progressEvent) => {
            const percent = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            // if (percent === 100) {
            //   alert("✅ File uploaded. After analysing we will notify you.");
            // }
            setUploadProgress(percent);
          },
        }
      );

      console.log("Detection Result:", response.data);
      setResult(response.data.results);
      // fetchData(); // refresh dashboard stats
    } catch (err) {
      console.error("Upload error:", err);
      setError("⚠️ Upload failed. Please try again.");
    }
  };

  // Fetch dashboard data from backend
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(
          `${import.meta.env.VITE_BACKEND_URL}/api/admin/dashboard`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );

        setStats(res.data.stats);
        setUploadTrends(res.data.uploadTrends);
        setDetectionRatios(res.data.detectionRatios);
      } catch (err) {
        console.error("Error fetching dashboard data", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <p className="loading">Loading dashboard...</p>;

  return (
    <>
      <Header title="Admin Dashboard" />
      <div className="dashboard-container">
        {/* Upload Section */}
        <div
          className="upload-card"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
        >
          <Upload size={32} />
          <h3>Upload File (Test Analysis)</h3>

          <input
            type="file"
            className="upload-input"
            onChange={handleFileChange}
          />

          {file && (
            <p className="file-info">
              Selected: <b>{file.name}</b>
            </p>
          )}

          {error && <p className="error-text">{error}</p>}

          {uploadProgress > 0 && (
            <div className="progress-bar">
              <div
                className="progress"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
          )}

          <button className="upload-btn" onClick={handleUpload}>
            Upload
          </button>
        </div>

        {/* Result Section */}
        {result && (
          <div className="result-card">
            <h3>Analysis Results</h3>

            {/* AI Image Detector */}
            <div className="result-section">
              <h4>AI Image Detector</h4>
              <div className="badges">
                {result["AI Image Detector"]?.map((item, idx) => (
                  <span
                    key={idx}
                    className={`badge ${
                      item.label === "artificial"
                        ? "badge-danger"
                        : "badge-success"
                    }`}
                  >
                    {item.label.toUpperCase()} – {(item.score * 100).toFixed(2)}
                    %
                  </span>
                ))}
              </div>
            </div>

            {/* Deepfake Detector */}
            <div className="result-section">
              <h4>Deepfake Detector</h4>
              <div className="badges">
                {result["Deepfake Detector"]?.map((item, idx) => (
                  <span
                    key={idx}
                    className={`badge ${
                      item.label === "Fake" ? "badge-danger" : "badge-success"
                    }`}
                  >
                    {item.label.toUpperCase()} – {(item.score * 100).toFixed(2)}
                    %
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* KPI Stats */}
        <div className="kpi-grid">
          <div className="kpi-card">
            <h4>Total Users</h4>
            <p>{stats.totalUsers}</p>
            <small>
              Active: {stats.activeUsers} | Inactive: {stats.inactiveUsers}
            </small>
          </div>
          <div className="kpi-card">
            <h4>Total Uploads</h4>
            <p>{stats.totalUploads}</p>
            <small>
              Today: {stats.uploadsToday} | This Week: {stats.uploadsThisWeek}
            </small>
          </div>
          <div className="kpi-card">
            <h4>Files Flagged</h4>
            <p>
              {stats.flaggedAI + stats.flaggedDeepfake + stats.flaggedUncertain}
            </p>
            <small>
              AI: {stats.flaggedAI} | Deepfake: {stats.flaggedDeepfake} |
              Uncertain: {stats.flaggedUncertain}
            </small>
          </div>
          {/* <div className="kpi-card alerts">
            <h4>System Alerts</h4>
            <p>{stats.systemAlerts || "No alerts"}</p>
            <small>Failed uploads, errors, warnings</small>
          </div> */}
        </div>

        {/* Charts Section */}
        <div className="charts-grid">
          {/* Upload Trends */}
          <div className="chart-card">
            <h3>Upload Trends</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={uploadTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="uploads" stroke="#4f46e5" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Detection Ratios */}
          <div className="chart-card">
            <h3>Detection Ratios</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={detectionRatios}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={120}
                  dataKey="value"
                >
                  {detectionRatios.map((entry, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Heatmap Placeholder */}
        <div className="chart-card">
          <h3>User Activity Heatmap</h3>
          <p>
            (TODO: Add Heatmap visualization using a lib like nivo or
            react-calendar-heatmap)
          </p>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
