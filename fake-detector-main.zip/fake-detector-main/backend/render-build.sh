#!/usr/bin/env bash
# Exit on errors
set -o errexit

# Install dependencies
npm install

# Install ffmpeg & ffprobe
apt-get update
apt-get install -y ffmpeg
