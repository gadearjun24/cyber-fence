// const express = require("express");
// const cors = require("cors");
// const multer = require("multer");
// const path = require("path");
// const detectRoutes = require("./routes/detect");
// require("dotenv").config();

// const app = express();
// const PORT = process.env.PORT || 5000;

// // Middleware
// app.use(cors());
// app.use(express.json());
// app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// // Routes
// app.use("/api/detect", detectRoutes);

// // Start server
// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });

// server.js
require("dotenv").config();
const express = require("express");
const http = require("http");
const cors = require("cors");
const mongoose = require("mongoose");
const path = require("path");
const { Server } = require("socket.io");
const authRoutes = require("./routes/auth");

// routes
const detectRoutes = require("./routes/detect");
const historyRoutes = require("./routes/history");
const adminRoutes = require("./routes/admin");

const app = express();

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, methods: ["GET", "POST"] },
});

// attach io to app so routes can emit events (or export io)
app.set("io", io);

app.use(
  cors({
    origin: "*",
  })
);
app.use(express.json({ limit: "100mb" }));
app.use(express.urlencoded({ limit: "100mb", extended: true }));
app.use(
  "/uploads",
  express.static(path.join(__dirname, process.env.UPLOAD_DIR || "uploads"))
);
app.use(express.static(path.join(__dirname, "public", "dist")));

// API routes
app.use("/api/detect", detectRoutes);
app.use("/api/history", historyRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);



// serve frondend

app.get(/.*/, (req, res) => {
  return res.sendFile(path.join(__dirname, "public", "dist" , "index.html"));
})

// MongoDB connect
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch((err) => {
    console.error("MongoDB connection error:", err);
    process.exit(1);
  });

// socket.io connection

// --- socket.io user mapping ---
const userSocketMap = {}; // userId -> socketId

io.on("connection", (socket) => {
  console.log("Socket connected:", socket.id);

  // client should send userId after login
  socket.on("register_user", (userId) => {
    userSocketMap[userId] = socket.id;
    console.log(`User ${userId} mapped to socket ${socket.id}`);
  });

  socket.on("disconnect", () => {
    for (const [uid, sid] of Object.entries(userSocketMap)) {
      if (sid === socket.id) {
        delete userSocketMap[uid];
        console.log(`User ${uid} disconnected`);
        break;
      }
    }
  });
});

// expose userSocketMap
app.set("userSocketMap", userSocketMap);

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
