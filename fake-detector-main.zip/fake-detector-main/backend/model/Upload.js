// models/Upload.js
const mongoose = require("mongoose");

const UploadSchema = new mongoose.Schema({
  filename: { type: String, required: true },
  originalName: { type: String },
  mimetype: { type: String },
  size: { type: Number },
  url: { type: String }, // optional: static/hosted URL to file
  results: { type: mongoose.Schema.Types.Mixed }, // store the raw detectors output
  verdict: { type: String }, // combined verdict string e.g., "AI-Generated", "Deepfake", "Real", "Uncertain"
  confidence: { type: Number }, // main confidence value (0-100)
  createdAt: { type: Date, default: Date.now },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // reference to User model
});

module.exports = mongoose.model("Upload", UploadSchema);
