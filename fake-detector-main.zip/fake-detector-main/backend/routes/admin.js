// routes/admin.js
const express = require("express");
const auth = require("../middleware/auth");
const Upload = require("../model/Upload");
const {
  deleteUser,
  updateUser,
  getUsers,
} = require("../controller/adminController");
const User = require("../model/User");
const router = express.Router();

// GET users with pagination, search, filters
router.get("/users", auth, getUsers);

// PATCH user (role update, suspend/unsuspend)
router.patch("/user/:id", auth, updateUser);

// DELETE user
router.delete("/user/:id", auth, deleteUser);

router.get("/dashboard", auth, async (req, res) => {
  try {
    const userId = req.user.id;
    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const user = await User.findById(userId);

    if (!user || user.role !== "admin") {
      return res.status(403).json({ error: "Forbidden" });
    }
    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ isSuspended: false });
    const inactiveUsers = totalUsers - activeUsers;

    const totalUploads = await Upload.countDocuments();
    const uploadsToday = await Upload.countDocuments({
      createdAt: { $gte: new Date().setHours(0, 0, 0, 0) },
    });
    const uploadsThisWeek = await Upload.countDocuments({
      createdAt: {
        $gte: new Date(new Date().setDate(new Date().getDate() - 7)),
      },
    });

    const flaggedAI = await Upload.countDocuments({ verdict: "AI-Generated" });
    const flaggedDeepfake = await Upload.countDocuments({
      verdict: "Deepfake/Manipulated",
    });
    const flaggedUncertain = await Upload.countDocuments({
      verdict: "Uncertain",
    });

    // const systemAlerts = await Upload.countDocuments({ status: "failed" });

    // Upload Trends (daily counts for last 7 days)
    const uploadTrends = await Upload.aggregate([
      {
        $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
          uploads: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    // Detection Ratios
    const detectionRatios = [
      { name: "AI-Generated", value: flaggedAI },
      { name: "Deepfake", value: flaggedDeepfake },
      { name: "Uncertain", value: flaggedUncertain },
      {
        name: "Real",
        value: totalUploads - (flaggedAI + flaggedDeepfake + flaggedUncertain),
      },
    ];

    res.json({
      stats: {
        totalUsers,
        activeUsers,
        inactiveUsers,
        totalUploads,
        uploadsToday,
        uploadsThisWeek,
        flaggedAI,
        flaggedDeepfake,
        flaggedUncertain,
        // systemAlerts,
      },
      uploadTrends: uploadTrends.map((u) => ({
        date: u._id,
        uploads: u.uploads,
      })),
      detectionRatios,
    });
  } catch (err) {
    console.error("Admin dashboard error:", err);
    res.status(500).json({ error: "Failed to load dashboard" });
  }
});

module.exports = router;
