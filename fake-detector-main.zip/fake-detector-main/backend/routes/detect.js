// // const express = require("express");
// // const multer = require("multer");
// // const fs = require("fs");
// // const path = require("path");
// // const axios = require("axios");
// // require("dotenv").config();

// // const router = express.Router();

// // // Multer config for file uploads
// // const storage = multer.diskStorage({
// //   destination: (req, file, cb) => {
// //     cb(null, "uploads/");
// //   },
// //   filename: (req, file, cb) => {
// //     cb(null, Date.now() + "-" + file.originalname);
// //   },
// // });
// // const upload = multer({ storage });

// // // Helper: call Hugging Face Inference API
// // async function hfImageDetect(model, filePath) {
// //   const imageData = fs.readFileSync(filePath);

// //   const response = await axios.post(
// //     `https://api-inference.huggingface.co/models/${model}`,
// //     imageData,
// //     {
// //       headers: {
// //         Authorization: `Bearer ${process.env.HF_API_KEY}`,
// //         "Content-Type": "application/octet-stream",
// //       },
// //     }
// //   );

// //   return response.data;
// // }

// // // POST /api/detect/file
// // router.post("/file", upload.single("file"), async (req, res) => {
// //   try {
// //     console.log("Time: ", new Date());
// //     const filePath = path.join(__dirname, "../uploads", req.file.filename);
// //     const ext = path.extname(req.file.originalname).toLowerCase();

// //     console.log({ filePath, ext });
// //     if (![".jpg", ".jpeg", ".png"].includes(ext)) {
// //       return res.status(400).json({ error: "Only images supported" });
// //     }

// //     // Run both models
// //     const aiDetector = await hfImageDetect(
// //       "umm-maybe/AI-image-detector",
// //       filePath
// //     );
// //     const deepfakeDetector = await hfImageDetect(
// //       "dima806/deepfake_vs_real_image_detection",
// //       filePath
// //     );
// //     console.log({
// //       success: true,
// //       results: {
// //         "AI Image Detector": aiDetector,
// //         "Deepfake Detector": deepfakeDetector,
// //       },
// //     });

// //     // Remove uploaded file
// //     fs.unlinkSync(filePath);

// //     return res.json({
// //       success: true,
// //       results: {
// //         "AI Image Detector": aiDetector,
// //         "Deepfake Detector": deepfakeDetector,
// //       },
// //     });
// //   } catch (err) {
// //     console.error({ err });
// //     return res.status(500).json({ error: "Internal Server Error" });
// //   }
// // });

// // module.exports = router;

// // routes/detect.js
// const express = require("express");
// const router = express.Router();
// const multer = require("multer");
// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const Upload = require("../model/Upload");
// const auth = require("../middleware/auth");

// const UPLOAD_DIR = process.env.UPLOAD_DIR || "uploads";
// if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

// // Multer storage
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => cb(null, UPLOAD_DIR),
//   filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
// });
// const upload = multer({ storage });

// // Helper: call Hugging Face Inference API for images
// async function hfImageDetect(modelId, filePath) {
//   const imageData = fs.readFileSync(filePath);
//   const res = await axios.post(
//     `https://api-inference.huggingface.co/models/${modelId}`,
//     imageData,
//     {
//       headers: {
//         Authorization: `Bearer ${process.env.HF_API_KEY}`,
//         "Content-Type": "application/octet-stream",
//       },
//       timeout: 120000,
//     }
//   );
//   return res.data;
// }

// // Simple combine logic (tweak thresholds as you like)
// function combineResults(aiRes, dfRes) {
//   // aiRes: array [{label, score},...]
//   // dfRes: array [{label, score},...]
//   const aiArtificial =
//     aiRes.find((r) => /artificial|fake|synthetic/i.test(r.label))?.score || 0;
//   const aiHuman = aiRes.find((r) => /human|real/i.test(r.label))?.score || 0;

//   const dfFake =
//     dfRes.find((r) => /fake|manipulated/i.test(r.label))?.score || 0;
//   const dfReal = dfRes.find((r) => /real|authentic/i.test(r.label))?.score || 0;

//   // Decide final verdict
//   if (aiArtificial > 0.8 && dfReal > 0.6) {
//     return {
//       verdict: "AI-Generated",
//       confidence: Math.round(aiArtificial * 100),
//     };
//   }
//   if (dfFake > 0.6) {
//     return {
//       verdict: "Deepfake/Manipulated",
//       confidence: Math.round(dfFake * 100),
//     };
//   }
//   if (aiHuman > 0.7 && dfReal > 0.7) {
//     return {
//       verdict: "Real",
//       confidence: Math.round(((aiHuman + dfReal) / 2) * 100),
//     };
//   }
//   return {
//     verdict: "Uncertain",
//     confidence: Math.round(
//       Math.max(aiArtificial, aiHuman, dfFake, dfReal) * 100
//     ),
//   };
// }

// // POST /api/detect/file
// router.post("/file", auth, upload.single("file"), async (req, res) => {
//   const io = req.app.get("io"); // socket.io instance
//   const userSocketMap = req.app.get("userSocketMap");
//   const userId = req.user.id;

//   if (!req.file) return res.status(400).json({ error: "No file uploaded" });

//   const filePath = path.join(UPLOAD_DIR, req.file.filename);
//   const ext = path.extname(req.file.originalname).toLowerCase();

//   // we'll only run detectors for images here. For video/audio you can extend (extract frames etc.)
//   if (![".jpg", ".jpeg", ".png"].includes(ext)) {
//     // cleanup
//     fs.unlinkSync(filePath);
//     return res
//       .status(400)
//       .json({ error: "Only image files supported for this endpoint" });
//   }

//   try {
//     // immediate ack to client - file accepted
//     // Option: emit started event to a room or socket id if you pass it in request
//     // Here we will just process and then send final event.
//     const models = {
//       ai: process.env.HF_MODEL_AI || "umm-maybe/AI-image-detector",
//       df: process.env.HF_MODEL_DF || "dima806/deepfake_vs_real_image_detection",
//     };

//     // call models in parallel
//     const [aiRes, dfRes] = await Promise.all([
//       hfImageDetect(models.ai, filePath),
//       hfImageDetect(models.df, filePath),
//     ]);

//     // combine
//     const combined = combineResults(aiRes, dfRes);

//     // build DB record
//     const uploadDoc = await Upload.create({
//       filename: req.file.filename,
//       originalName: req.file.originalname,
//       mimetype: req.file.mimetype,
//       size: req.file.size,
//       url: `/uploads/${req.file.filename}`,
//       results: { "AI Image Detector": aiRes, "Deepfake Detector": dfRes },
//       verdict: combined.verdict,
//       confidence: combined.confidence,
//     });

//     console.log({ uploadDoc });

//     // emit via socket.io to all clients (or you can target specific user with rooms)
//     const socketId = userSocketMap[userId];
//     if (socketId) {
//       io.to(socketId).emit("analysis_complete", {
//         id: uploadDoc._id,
//         filename: uploadDoc.originalName,
//         verdict: uploadDoc.verdict,
//         confidence: uploadDoc.confidence,
//         url: uploadDoc.url,
//         seen: false,
//         createdAt: uploadDoc.createdAt,
//       });
//     }

//     // respond to HTTP caller
//     res.json({
//       success: true,
//       results: { "AI Image Detector": aiRes, "Deepfake Detector": dfRes },
//       verdict: combined,
//     });
//   } catch (err) {
//     console.error(
//       "Detection error:",
//       err?.response?.data || err.message || err
//     );
//     res.status(500).json({ error: "Processing failed" });
//   } finally {
//     // cleanup file
//     try {
//       // if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
//     } catch (e) {}
//   }
// });

// module.exports = router;

const express = require("express");
const router = express.Router();
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const Upload = require("../model/Upload");
const auth = require("../middleware/auth");
const ffmpeg = require("fluent-ffmpeg");
const User = require("../model/User");

const UPLOAD_DIR = process.env.UPLOAD_DIR || "uploads";
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

// Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});
const upload = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } });

// Helper: call Hugging Face Inference API for images
async function hfImageDetect(modelId, filePath) {
  const imageData = fs.readFileSync(filePath);
  const res = await axios.post(
    `https://api-inference.huggingface.co/models/${modelId}`,
    imageData,
    {
      headers: {
        Authorization: `Bearer ${process.env.HF_API_KEY}`,
        "Content-Type": "application/octet-stream",
      },
      timeout: 120000,
    }
  );
  return res.data;
}

// Combine logic (thresholds can be adjusted)
function combineResults(aiRes, dfRes) {
  const aiArtificial =
    aiRes.find((r) => /artificial|fake|synthetic/i.test(r.label))?.score || 0;
  const aiHuman = aiRes.find((r) => /human|real/i.test(r.label))?.score || 0;

  const dfFake =
    dfRes.find((r) => /fake|manipulated/i.test(r.label))?.score || 0;
  const dfReal = dfRes.find((r) => /real|authentic/i.test(r.label))?.score || 0;

  if (aiArtificial > 0.8 && dfReal > 0.6) {
    return {
      verdict: "AI-Generated",
      confidence: Math.round(aiArtificial * 100),
    };
  }
  if (dfFake > 0.6) {
    return {
      verdict: "Deepfake/Manipulated",
      confidence: Math.round(dfFake * 100),
    };
  }
  if (aiHuman > 0.7 && dfReal > 0.7) {
    return {
      verdict: "Real",
      confidence: Math.round(((aiHuman + dfReal) / 2) * 100),
    };
  }
  return {
    verdict: "Uncertain",
    confidence: Math.round(
      Math.max(aiArtificial, aiHuman, dfFake, dfReal) * 100
    ),
  };
}

// Helper: extract frames from video
function extractFrames(videoPath, outputDir, fps = 1) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir);
    ffmpeg(videoPath)
      .on("end", () => {
        const frames = fs
          .readdirSync(outputDir)
          .map((f) => path.join(outputDir, f));
        resolve(frames);
      })
      .on("error", (err) => reject(err))
      .output(path.join(outputDir, "frame-%04d.jpg"))
      .outputOptions([`-vf fps=${fps}`])
      .run();
  });
}

// POST /api/detect/file
router.post("/file", auth, upload.single("file"), async (req, res) => {
  const io = req.app.get("io"); // socket.io instance
  const userSocketMap = req.app.get("userSocketMap");
  const userId = req.user.id;

  if (!req.file) return res.status(400).json({ error: "No file uploaded" });

  const filePath = path.join(UPLOAD_DIR, req.file.filename);
  const ext = path.extname(req.file.originalname).toLowerCase();

  try {
    const models = {
      ai: process.env.HF_MODEL_AI || "umm-maybe/AI-image-detector",
      df: process.env.HF_MODEL_DF || "dima806/deepfake_vs_real_image_detection",
    };

    let aiRes, dfRes;

    if ([".jpg", ".jpeg", ".png"].includes(ext)) {
      // Image file — same as before
      [aiRes, dfRes] = await Promise.all([
        hfImageDetect(models.ai, filePath),
        hfImageDetect(models.df, filePath),
      ]);
    } else if ([".mp4", ".mov", ".avi", ".mkv"].includes(ext)) {
      // Video file — extract frames and analyze
      const framesDir = path.join(UPLOAD_DIR, "frames-" + Date.now());
      const framePaths = await extractFrames(filePath, framesDir, 1); // 1 fps

      const aiResults = [];
      const dfResults = [];

      for (const frame of framePaths) {
        const [aiFrame, dfFrame] = await Promise.all([
          hfImageDetect(models.ai, frame),
          hfImageDetect(models.df, frame),
        ]);
        aiResults.push(...aiFrame);
        dfResults.push(...dfFrame);

        // remove frame to save space
        fs.unlinkSync(frame);
      }

      fs.rmdirSync(framesDir);

      // Average the results
      const avgScores = (results) => {
        const map = {};
        results.forEach((r) => {
          if (!map[r.label]) map[r.label] = [];
          map[r.label].push(r.score);
        });
        return Object.entries(map).map(([label, scores]) => ({
          label,
          score: scores.reduce((a, b) => a + b, 0) / scores.length,
        }));
      };

      aiRes = avgScores(aiResults);
      dfRes = avgScores(dfResults);
    } else {
      return res
        .status(400)
        .json({ error: "Unsupported file type for detection" });
    }

    const combined = combineResults(aiRes, dfRes);

    // Save upload record
    const uploadDoc = await Upload.create({
      filename: req.file.filename,
      originalName: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      url: `/uploads/${req.file.filename}`,
      results: { "AI Image Detector": aiRes, "Deepfake Detector": dfRes },
      verdict: combined.verdict,
      confidence: combined.confidence,
      user: userId,
    });

    const userData = await User.findById(userId);
    userData.uploadsCount = userData.uploadsCount + 1;
    await userData.save();
    // Emit via socket.io to specific user
    const socketId = userSocketMap[userId];
    if (socketId) {
      io.to(socketId).emit("analysis_complete", {
        id: uploadDoc._id,
        filename: uploadDoc.originalName,
        verdict: uploadDoc.verdict,
        confidence: uploadDoc.confidence,
        url: uploadDoc.url,
        createdAt: uploadDoc.createdAt,
      });
    }

    res.json({
      success: true,
      results: { "AI Image Detector": aiRes, "Deepfake Detector": dfRes },
      verdict: combined,
    });
  } catch (err) {
    console.error(
      "Detection error:",
      err?.response?.data || err.message || err
    );
    res.status(500).json({ error: "Processing failed" });
  } finally {
    // cleanup uploaded file
    try {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    } catch (e) {}
  }
});

module.exports = router;
